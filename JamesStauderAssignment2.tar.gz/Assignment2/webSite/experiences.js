var experiences = {"ComputerScience": [], "Teaching": [], "Misc": []};

experiences.Misc.push({"Job Title": "Waiter/Bartender", "Time Worked" : "2012, 2013-2014", "Employer": "Wingers, Chevy's, Red Robin"});
experiences.Misc.push({"Job Title": "Alarm Technician", "Time Worked" : "Summers 2012-2014", "Employer": "Vivint"});

experiences.Teaching.push({"Job Title": "Substitute Teacher", "Time Worked" : "2013-2014", "Employer": "Sonoma County"});
experiences.Teaching.push({"Job Title": "High School Comp Sci", "Time Worked" : "2018", "Employer": "University of Montana"});


experiences.ComputerScience.push({"Job Title": "Grader", "Time Worked" : "2016", "Employer": "University of Montana/Intro to Java"});
experiences.ComputerScience.push({"Job Title": "IT", "Time Worked" : "2017", "Employer": "University of Montana/Journalism Department"});
experiences.ComputerScience.push({"Job Title": "Teaching Assistant", "Time Worked" : "2017", "Employer": "University of Montana/Data Structures"});
experiences.ComputerScience.push({"Job Title": "Research Assistant", "Time Worked" : "2017-2018", "Employer": "University of Montana/QSSI Lab"});

